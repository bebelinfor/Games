package com.example.velha;

import android.app.Activity;

public class MainActivity extends Activity {
}
